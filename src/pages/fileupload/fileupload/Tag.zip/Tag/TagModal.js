import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from '@material-ui/core';
import axios from 'axios';

const TagModal = ({ isOpen, onClose }) => {
  const [tagName, setTagName] = useState('');

  const handleCreateTag = async () => {
    // Your axios post request here
    try {
      const formData = new FormData();
      formData.append('tagName', tagName);

      const response = await axios.post(
        "http://127.0.0.1:8000/file/create_tag/",
        formData,
        {
          withCredentials: true,
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // Handle the response as needed

      // Close the modal
      onClose();
    } catch (error) {
      // Handle error
      console.error('Error creating tag:', error);
    }
  };

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>Create Tag</DialogTitle>
      <DialogContent>
        <TextField
          label="Tag Name"
          value={tagName}
          onChange={(e) => setTagName(e.target.value)}
          fullWidth
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={handleCreateTag} color="primary">
          Create
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default TagModal;
