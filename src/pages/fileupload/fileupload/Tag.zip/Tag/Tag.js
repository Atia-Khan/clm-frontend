import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, MenuItem } from '@mui/material';

const Tag = ({ onSelect }) => {
  const [open, setOpen] = useState(false);
  const [tagName, setTagName] = useState('');
  const [tags, setTags] = useState([]);
  const [isDoubleDropdownOpen, setIsDoubleDropdownOpen] = useState(false);

  const [selectedOption, setSelectedOption] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleInputChange = (e) => {
    setTagName(e.target.value);
  };

  const handleModalToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const handleCreateTag = async () => {
    try {
      const formData = new FormData();
      formData.append('tag_name', tagName);

      const response = await axios.post(
        "http://127.0.0.1:8000/file/create_tag/",
        formData,
        {
          withCredentials: true,
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // Handle the response as needed
      console.log(response);

      // Close the modal after creating the tag
      setOpen(false);

      // Update tags with the new tag
      setTags([...tags, response.data.tag]);

      // Select the newly created tag
      setSelectedOption(response.data.tag.name);

      // Optionally, execute onSelect
      if (typeof onSelect === 'function') {
        onSelect(response.data.tag);
      }
    } catch (error) {
      // Handle errors
      console.error(error);
    }
  };

  const toggleDoubleDropdown = () => {
    setIsDoubleDropdownOpen((prevOpen) => !prevOpen);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen((prevOpen) => !prevOpen);
  };

  useEffect(() => {
    const fetchTags = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/file/get_tags/");
        setTags(response.data.tags);
      } catch (error) {
        console.error("Error fetching tags", error);
      }
    };
    fetchTags();
    
  }, []);

  return (
    <div className="sm:col-span-2 relative">
    <input
          type="text"
          value={selectedOption}
          readOnly
          onClick={toggleDropdown}
          style={{ color: "black" }}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
        />

      {isDropdownOpen && (
        <div className="z-10 absolute mt-2">
          <div
            id="multi-dropdown"
            className="bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700"
          >
            <ul
              className="py-2 text-sm text-gray-700 dark:text-gray-200"
              aria-labelledby="multiLevelDropdownButton"
            >
              <li>
                <button
                  onClick={handleModalToggle}
                  style={{ color: "black" }}
                  className="block px-4 py-2 dark:text-black transition duration-300 ease-in-out hover:bg-gray-100 hover:text-gray-800"
                >
                  Create tag
                </button>
              </li>
              <li>
                <button
                  id="doubleDropdownButton"
                  style={{ color: "black" }}
                  className="flex items-center justify-between w-full px-4 py-2 dark:text-black transition duration-300 ease-in-out hover:bg-gray-100 hover:text-gray-800"
                  type="button"
                  onClick={toggleDoubleDropdown}
                >
                  Show All Tags
                </button>

                {isDoubleDropdownOpen && (
                  <div className="z-10 absolute left-44 mt-0">
                    <div className="bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                      <ul
                        className="py-2 text-sm text-gray-700 dark:text-gray-200"
                        aria-labelledby="doubleDropdownButton"
                      >
                        {tags.map((tag) => (
                          <li key={tag.id}>
                            <button
                              onClick={() => {
                                setIsDoubleDropdownOpen(false);
                                toggleDropdown();
                                setSelectedOption(tag);
                                if (typeof onSelect === 'function') {
                                  onSelect(tag);
                                }
                              }}
                              style={{ color: "black" }}
                              className="flex items-center justify-between w-full px-4 py-2 dark:text-black transition duration-300 ease-in-out hover:bg-gray-100 hover:text-gray-800"
                            >
                              {tag}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </li>
            </ul>
          </div>
        </div>
      )}

<Dialog open={open} onClose={handleModalToggle}>
  <DialogTitle>Create Tag</DialogTitle>
  <DialogContent>
    <TextField
      label="Tag Name"
      value={tagName}
      onChange={handleInputChange}
      fullWidth
      style={{ color: "black" }}
      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
    />
  </DialogContent>
  <DialogActions>
    <Button onClick={handleCreateTag} color="primary">
      Create Tag
    </Button>
    <Button onClick={handleModalToggle}>Cancel</Button>
  </DialogActions>
</Dialog>

    </div>
  );
};

export default Tag;
